<div class="case-study">
                  <a href="<?php echo $cardLink;?>">
                     <div class="card">
                        <div class="image-wrapper">
                         <img src="<?php echo $cardImg;?>" alt="<?php echo $cardImgAlt;?>">
                        </div>
                        <div class="card-inner">
                           <h6 class="card-title bold">
                              <?php echo $cardTitle;?>
                           </h6>
                           <p class="card-body">
                             <?php echo $cardBody;?>
                           </p>
                  <a href="<?php echo $cardLink;?>" class="card-link d-inline top-md">View case study</a>
                  </div>
                  </div>
                  </a>
               </div>