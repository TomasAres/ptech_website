<section class="container-fluid hero-bg" id="hero">
   <div class="hero text-center d-flex flex-column justify-content-center">
      <h1 class="hero-title bold white">
      {{home_hero_title}} <br>
         <div class="typewriter" id="typing-en"></div>
         <div class="typewriter" id="typing-es"></div>
         <div class="typewriter" id="typing-pt"></div>
      </h1>
      <h5 class="hero-subtitle gray top-md">
      {{home_hero_subtitle}}       </h5>
   </div>
</section>