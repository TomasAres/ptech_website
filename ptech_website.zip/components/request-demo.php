<section class="container-fluid bg-black bottom-xxl" id="demo">
   <div class="container">
      <div>
         <div class="row d-flex align-items-center justify-content-center">
            <div class="col-md-8">
               <div class="text-center">
                  <h3 class="semibold white bottom-lg">The right solution for your business</h3>  
                  <p class="home-text">CONNECTED offers a wide range of integration services, allowing you to easily connect your existing systems and data to our platform.</p>
                  <p class="home-text">
                  In adition, our platform is highly customizable to meet the unique needs of each client. Our team can work with you to tailor the system to your exact requirements.
                  </p>
                  <div class="button-wrapper top-xl"><a class="button big" href="/contact.php">Request a demo</a></div>

               </div>
            </div>
            </div>
         </div>
      </div>
   </div>
</section>