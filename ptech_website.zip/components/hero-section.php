<section class="container-fluid hero-bg" id="hero">
   <div class="hero text-center d-flex flex-column justify-content-center">
      <h1 class="hero-title bold white">
         We help businesses<br>
         <div id="typing"></div>
      </h1>
      <h5 class="hero-subtitle gray top-md">
         Maximize your company's potential
      </h5>
   </div>
</section>