<section >
<div id="loading">
<div class="lds-dual-ring"></div>
</div>
</section>