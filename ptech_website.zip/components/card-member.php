<div class="team-member">
                     <div class="card">
                        <div class="image-wrapper">
                         <img src="<?php echo $cardImg;?>" alt="<?php echo $cardImgAlt;?>">
                        </div>
                        <div class="card-inner">
                           <h6 class="card-title bold">
                              <?php echo $cardTitle;?>
                           </h6>
                           <p class="card-body">
                             <?php echo $cardBody;?>
                           </p>
                  </div>
                  </div>
               </div>