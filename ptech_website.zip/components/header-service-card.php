<div class="col-md-3 d-none d-md-block">
    <div class="service">
       <div class="service-header d-inline d-flex align-items-center">
        <h6 class="service-title bold white"><?php echo $serviceTitle;?></h6>
       </div>
       <div class="service-body">
          <p>
             <?php echo $serviceDescription;?>
          </p>
          <a href="<?php echo $serviceLink;?>" class="service-link top-sm d-block"><?php echo $serviceLinkText;?></a>
       </div>
    </div>
 </div>

 